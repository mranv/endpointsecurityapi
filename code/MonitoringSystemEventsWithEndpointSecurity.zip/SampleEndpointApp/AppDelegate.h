/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The delegate that receives app-related events from the system.
*/
#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSUserNotificationCenterDelegate>

@end

/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The delegate that receives app-related events from the system.
*/
#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your app.
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your app.
}

@end
